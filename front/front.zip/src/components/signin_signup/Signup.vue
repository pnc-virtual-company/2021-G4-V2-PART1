<template>
    <div class="login-form">
        <form class="sign-in-form" @submit.prevent="submitData">
        <div>
            <h1>Sign Up</h1>
            <div id="intro-text">
            <span>Already have account?
                <router-link class="link" to="/signin">Sign in</router-link>
            </span>
            </div>
        </div>
        <div id="text"><b> or</b></div>
        <div>
            <hr id="hr" />
        </div>
        <div class="devide">
            <input type="text" id="left" placeholder="Firstname" v-model="firstname" />
            <input type="text" id="right" placeholder="Lastname" v-model="lastname" />
        </div>
        <small v-show="mss_username!=''" class='mss'>{{mss_username}}</small>
        <div>
            <input type="email" placeholder="Email" v-model="email" />
        </div>
        <small v-show="mss_email!=''" class='mss'>{{mss_email}}</small>
        <div>
            <input type="password" placeholder="Password" v-model="password" />
        </div>
        <div>
            <input id='mb-0' type="password" placeholder="Confirm Password" v-model="confirmpassword" />
        </div>
        <div>
            <small v-show="mss_pass!=''" class='mss'>{{mss_pass}}</small>
        </div>
        <div>
            <!-- mss_username!=''&&mss_password!=''&&mss_email!='' -->
            <router-link to="/menu"><button class='button'>Sign In</button></router-link>
        </div>
        </form>
    </div>
</template>

<script>
export default {
    emits:["add-user"],
    inject:['users'],
    data(){
        return {
            firstname:"",
            lastname:"",
            email:"",
            password:"",
            confirmpassword:"",
            mss_pass:"",
            mss_username:"",
            mss_email:"",

        }
    },
    methods:{
        submitData(){
            console.log(this.firstname, this.lastname, this.email, this.password,this.confirmpassword)
            if(this.password!="" && this.confirmpassword!=""){
                if(this.password===this.confirmpassword){
                this.$emit(
                    "add-user",
                    this.firstname,
                    this.lastname,
                    this.email,
                    this.password
                );
                this.mss_pass=""
                }else{
                this.mss_pass="Your Password does not match!";
                this.password="";
                this.confirmpassword="";
                }
            }
            else{
                this.mss_pass="password field cannot be empty!"
                
            }
            if(this.firstname==="" || this.lastname===""){
                this.mss_username="username fields cannot be empty!"
            }
            else{
                this.mss_username=""
            }
            if(this.email===""){
                this.mss_email="email field cannot be empty!"
            }else{
                this.mss_email=""
            }
            
            
            
            
        }
    }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

    .login-form{
        border: 1px solid black;
        background: #B0F0EC;
        width: 350px;
        height: 100%;
        padding: 20px;
        border-radius: 10px;
        font-family: 'Arial';
        margin: auto;
         margin-top:100px;
    }
    #intro-text{
        margin-left: 10px;
        font-size: 14px;
        margin-bottom: 10px;
    }
    .link{
        text-decoration: none;
        color: rgb(201, 110, 7);
        font-weight: bolder;
    }
    input,button{
        background: rgb(211, 211, 211);
        width:100%;
        margin: 5px 0px;
        padding: 7px;
        border-radius: 50px;
        border: 1px solid black;
    }
    .devide{
        display: flex;
        width:100%;
    }
    input[type="text"], #left{
        margin-left: 0;
        margin-right: 5px;
    }
    input[type="text"], #right{
        margin-right: 0;
        margin-left: 5px;
    }
    input:hover{
        background: white;
    }
    ::placeholder{
        text-align: center;
    }
    button{
        width:100%;
    }
    button{
    background: #5fb6b6;
    }
    button:hover{
        background: #3d7575;
        color: white;
    }

    #hr{
        background: #000;
        height: 1px;
        border: none;
        margin-top: 27px;
        margin-bottom: 15px;
    }
    #text{
        margin-left:135px;
        position:absolute;
        border-radius: 40px;
        width: 40px;
        padding: 8px;
        background: #ffffff;
    }
    .mss{
        color:red;
        margin-left: 20px;
        font-weight: bold;
    }
</style>



