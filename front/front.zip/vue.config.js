module.exports = {
  publicPath: './'
};
